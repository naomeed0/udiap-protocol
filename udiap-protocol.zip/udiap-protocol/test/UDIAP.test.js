const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("UDIAP Protocol", function () {
  let token, identity;
  let owner, user1, user2;

  beforeEach(async function () {
    [owner, user1, user2] = await ethers.getSigners();

    // Deploy contracts
    const UniversalToken = await ethers.getContractFactory("UniversalToken");
    token = await UniversalToken.deploy();
    
    const SoulboundIdentity = await ethers.getContractFactory("SoulboundIdentity");
    identity = await SoulboundIdentity.deploy();
  });

  describe("UniversalToken", function () {
    it("Should deploy with correct name and symbol", async function () {
      expect(await token.name()).to.equal("Universal Network Identity");
      expect(await token.symbol()).to.equal("UNI");
    });

    it("Should allow airdrop claim", async function () {
      await token.connect(user1).claimAirdrop(ethers.constants.AddressZero);
      expect(await token.balanceOf(user1.address)).to.equal(ethers.utils.parseEther("10"));
    });
  });

  describe("SoulboundIdentity", function () {
    it("Should create digital identity", async function () {
      const biometricHash = ethers.utils.id("test_face_data");
      await identity.connect(user1).createIdentity("Test User", biometricHash);
      
      const identityInfo = await identity.getIdentity(user1.address);
      expect(identityInfo.name).to.equal("Test User");
      expect(identityInfo.reputation).to.equal(100);
    });
  });
});