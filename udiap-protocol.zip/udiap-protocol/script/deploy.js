const { ethers } = require("hardhat");

async function main() {
  console.log("🚀 Starting UDIAP Protocol Deployment...");
  
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with account:", deployer.address);

  // Deploy UniversalToken
  console.log("📦 Deploying UniversalToken...");
  const UniversalToken = await ethers.getContractFactory("UniversalToken");
  const token = await UniversalToken.deploy();
  console.log("UniversalToken deployed to:", token.address);

  // Deploy SoulboundIdentity
  console.log("🆔 Deploying SoulboundIdentity...");
  const SoulboundIdentity = await ethers.getContractFactory("SoulboundIdentity");
  const identity = await SoulboundIdentity.deploy();
  console.log("SoulboundIdentity deployed to:", identity.address);

  console.log("🎉 Deployment Complete!");
  console.log("========================");
  console.log("UniversalToken:", token.address);
  console.log("SoulboundIdentity:", identity.address);
  console.log("========================");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("Deployment failed:", error);
    process.exit(1);
  });